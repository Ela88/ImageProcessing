Bitte das Bild und das Write-File miteinbinden, wenn Sie das Programm in einem neuerstellten Projekt in NetBeans oder Eclipse verwenden.

Liebe Gr��e
Raphaela Feurstein