package fhv.pipes_and_filters.interfaces;

public interface Filter{
}
