package fhv.pipes_and_filters.pipeimpl.pull;

import fhv.pipes_and_filters.abstracts.filter.PullFilter;
import fhv.pipes_and_filters.abstracts.pipe.PullPipe;

public class BalledImagePullPipe extends PullPipe {

	public BalledImagePullPipe(PullFilter filter) {
		super(filter);
	}

}
